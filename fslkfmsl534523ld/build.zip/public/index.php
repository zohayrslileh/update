<?php

/**
 * |------------------------
 * |      APPLICATION
 * |------------------------
 */

define('BASEDIR', __DIR__ . '/..');

require_once BASEDIR . '/controller/Router/http/run.php';

# END