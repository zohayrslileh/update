<?php

use TOOL\SQL\Database;
use TOOL\SQL\SQL;
use TOOL\System\Path;

Path::open(BASEDIR)
    ->make('storage');

Path::open(BASEDIR)
    ->go('storage')
    ->make('cache');

Path::open(BASEDIR)
    ->go('storage')
    ->make('backups');

Path::open(BASEDIR)
    ->go('storage')
    ->createFiles(['.config', 'settings.json']);

Path::open(BASEDIR)
    ->go('public')
    ->make('uploads');

SQL::run("CREATE table IF NOT EXISTS `users` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `type` VARCHAR(15) NULL,
    `username` VARCHAR(20) NULL,
    `password` TEXT NULL,
    UNIQUE (`username`)
)");


SQL::set("INSERT IGNORE INTO `users` (id, type, username, password) VALUES
(1, 'admin', 'admin', :pass)")->exec([
    'pass' => password_hash('admin', PASSWORD_DEFAULT)
]);


SQL::run("CREATE table IF NOT EXISTS `categories` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `name` VARCHAR(50) NOT NULL,
    `image` TEXT NULL,
    UNIQUE (`name`)
)");


SQL::run("CREATE table IF NOT EXISTS `menu` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `category_id` INT(10) UNSIGNED NOT NULL,
    `name` VARCHAR(50) NOT NULL,
    `capital` FLOAT NOT NULL,
    `price` FLOAT NOT NULL,
    `quantity` FLOAT NULL,
    `equips_in` VARCHAR(10) NOT NULL,
    `image` TEXT NULL,
    CONSTRAINT `fk_menu_categories` FOREIGN KEY (category_id) REFERENCES categories(id),
    CHECK(`equips_in` IN ('kitchen','bartender')),
    CHECK(`quantity` = NULL OR `quantity` >= 0)
)");


SQL::run("CREATE table IF NOT EXISTS `areas` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `name` VARCHAR(50) NOT NULL
)");


SQL::run("CREATE table IF NOT EXISTS `tables` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `area_id` INT(10) UNSIGNED NOT NULL,
    `name` VARCHAR(50) NOT NULL,
    CONSTRAINT `fk_tables_areas` FOREIGN KEY (area_id) REFERENCES areas(id)
)");


SQL::run("CREATE table IF NOT EXISTS `customers` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `name` VARCHAR(50) NOT NULL,
    `address` VARCHAR(200) NULL,
    `phone` VARCHAR(30) NULL,
    UNIQUE (`name`)
)");


SQL::run("CREATE table IF NOT EXISTS `daily` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `close_at` TIMESTAMP NULL
)");


SQL::run("CREATE table IF NOT EXISTS `orders` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `daily_id` INT(10) UNSIGNED NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `table_id` INT NULL,
    `table_area` VARCHAR(20) NULL,
    `table_name` VARCHAR(20) NULL,
    `no_people` INT NULL,
    `customer_id` INT NULL,
    `customer_name` VARCHAR(50) NULL,
    `customer_address` VARCHAR(200) NULL,
    `customer_phone` VARCHAR(30) NULL,
    `paid` BOOLEAN NOT NULL DEFAULT 0,
    CONSTRAINT `fk_orders_daily` FOREIGN KEY (daily_id) REFERENCES daily(id),
    CHECK(`type` IN ('table','import', 'delivery'))
)");


SQL::run("CREATE table IF NOT EXISTS `sales` (
    -- Primary columns
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `create_by` INT,
    `create_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Custom columns
    `order_id` INT(10) UNSIGNED NOT NULL,
    `menu_id` INT NOT NULL,
    `equips_in` VARCHAR(10) NOT NULL,
    `title` VARCHAR(50) NOT NULL,
    `price` FLOAT NOT NULL,
    `capital` FLOAT NOT NULL,
    `qnt` FLOAT NOT NULL,
    `note` TEXT NULL,
    CONSTRAINT `fk_sales_orders` FOREIGN KEY (order_id) REFERENCES orders(id),
    CHECK(`qnt` >= 1)
)");
