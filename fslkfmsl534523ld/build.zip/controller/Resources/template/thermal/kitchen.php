<?php


use APP\Settings;
use Mike42\Escpos\Printer;
use TOOL\System\Thermal;

$items = array_filter($order->items, function ($item) {
    return $item->equips_in === 'kitchen';
});

if (!$items) return true;

$Settings = Settings::get();
$Printer = Thermal::create($Settings->printers->kitchen);

$Printer->setJustification(Printer::JUSTIFY_CENTER);
$Printer->setTextSize(2, 2);
$Printer->text(lang("Order No.") . " {$order->id}");
$Printer->feed(3);

$Printer->setJustification(Printer::JUSTIFY_LEFT);
$Printer->setTextSize(1, 1);
$Printer->setEmphasis(true);
$Printer->text(lang('Kitchen'));
$Printer->feed();
$Printer->text(lang("Type") . ": " . lang($order->type));
$Printer->feed();

if ($order->type === 'table')
    $Printer->text(lang("The number of people") . ": " . $order->no_people);
$Printer->feed();

$Printer->setJustification(Printer::JUSTIFY_CENTER);
$Printer->text("---------------------------------");
$Printer->feed();

$Printer->setJustification(Printer::JUSTIFY_LEFT);
$Printer->text(lang("Date") . ": " . lang($order->create_at));
$Printer->feed();

$Printer->setJustification(Printer::JUSTIFY_CENTER);
$Printer->text("---------------------------------");
$Printer->feed();


foreach ($items as $item) {

    $Printer->setJustification(Printer::JUSTIFY_LEFT);

    $Printer->setEmphasis(true);
    $Printer->text(lang("Title") . ": ");
    $Printer->setEmphasis(false);
    $Printer->text($item->title);
    $Printer->feed();

    $Printer->setEmphasis(true);
    $Printer->text(lang("Qnt") . ": ");
    $Printer->setEmphasis(false);
    $Printer->text($item->qnt);
    $Printer->feed();

    $Printer->setEmphasis(true);
    $Printer->text(lang("Note") . ": ");
    $Printer->setEmphasis(false);
    $Printer->text((string) $item->note);
    $Printer->feed();

    $Printer->setJustification(Printer::JUSTIFY_CENTER);
    $Printer->text("---------------------------------");
    $Printer->feed();
}

Thermal::end($Printer);
