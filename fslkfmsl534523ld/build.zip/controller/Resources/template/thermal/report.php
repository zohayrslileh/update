<?php


use APP\Settings;
use TOOL\System\Thermal;

$Settings = Settings::get();
$Printer = Thermal::create($Settings->printers->cashier);

$Printer->text(lang('REPORT'));

Thermal::end($Printer);
