<?php

use APP\Settings;
use Mike42\Escpos\EscposImage;
use Mike42\Escpos\Printer;
use TOOL\Helper\Convert;
use TOOL\System\Thermal;

$Settings = Settings::get();
$space = "            ";

$Printer = Thermal::create($Settings->printers->cashier);

$Printer->setJustification(Printer::JUSTIFY_CENTER);

if ($Settings->company->logo) {
    $Logo = EscposImage::load(BASEUPLOAD . '/' . $Settings->company->logo);
    $Printer->bitImage($Logo);
    $Printer->feed(1);
}

if ($Settings->company->name) {
    $Printer->setTextSize(2, 2);
    $Printer->text($Settings->company->name);
    $Printer->feed(2);
}

$Printer->setJustification(Printer::JUSTIFY_LEFT);
$Printer->setTextSize(1, 1);
$Printer->setEmphasis(true);
$Printer->text(lang('Payment'));
$Printer->feed();
$Printer->text(lang("Order No.") . " {$order->id}");
$Printer->feed();
$Printer->text(lang("Date") . ": " . lang($order->create_at));
$Printer->feed();
$Printer->text(lang("Type") . ": " . lang($order->type));
$Printer->feed();

if ($order->type === 'table') {
    $Printer->feed();
    $Printer->text(lang("Table") . ": {$order->table_area} - {$order->table_name}");
    $Printer->feed();
}

if ($order->type === 'delivery') {
    $Printer->feed();
    $Printer->text(lang("Customer") . ": {$order->customer_name}");
    $Printer->feed();
    $Printer->text(lang("Phone") . ": {$order->customer_phone}");
    $Printer->feed();
    $Printer->text(lang("Address") . ": {$order->customer_address}");
}

$Printer->feed();
$Printer->setJustification(Printer::JUSTIFY_CENTER);
$Printer->text("-------------------------------------------");
$Printer->feed();
$Printer->text(lang('Title'));
$Printer->feed();
$Printer->text(lang('Price') . $space . lang('Qnt') . $space . lang('Total'));
$Printer->feed();
$Printer->text("-------------------------------------------");
$Printer->feed();

$Printer->setEmphasis(false);

foreach ($order->items as $item) {

    $Printer->text($item->title);
    $Printer->feed();
    $Printer->text(Convert::price($item->price) . $space . $item->qnt . $space . Convert::price($item->price * $item->qnt));
    $Printer->feed();
    $Printer->text("-------------------------------------------");
    $Printer->feed();
}

$Printer->feed(2);
$Printer->setTextSize(1, 2);
$Printer->setEmphasis(true);
$Printer->text(lang("Total: ") . Convert::price(
    array_reduce($order->items, function ($total, $item) {
        return $total + floatval($item->price * $item->qnt);
    })
));

$Printer->feed(2);
$Printer->setTextSize(1, 1);
$Printer->text("---------------------------");
$Printer->feed();

if ($Settings->ticket->footer)
    $Printer->text($Settings->ticket->footer);


Thermal::end($Printer);
