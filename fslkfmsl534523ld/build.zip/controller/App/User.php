<?php

/**
 * |--------------
 * |    USER
 * |--------------
 */

namespace APP;

use TOOL\HTTP\RES;
use TOOL\HTTP\Filter;
use TOOL\Security\Token;
use TOOL\SQL\Curd\Extension as CurdExtension;

class User extends CurdExtension
{

    /**
     * LOGIN_ERROR
     * 
     * @var string
     */
    private const LOGIN_ERROR = 'Password or username is incorrect';

    /**
     * Curd options
     * 
     * @var array
     */
    protected static array $curdOptions = [
        'table' => 'users',
        'tableKey' => 'id',
        'ACCESS_READ' => true,
        'ACCESS_CREATE' => true
    ];

    /**
     * Login method
     * 
     * @param object $req
     * 
     * @return
     */
    static function login(object $req)
    {

        // Filter
        $valid = (object) Filter::check([
            ['username', $req->username, TRUE],
            ['password', $req->password, TRUE],
            ['remember', $req->remember, FALSE]
        ])->throw(lang(self::LOGIN_ERROR))->valid;

        // Get user
        $user = self::where("username = :username")->read(['username' => $valid->username])->data;

        if ($user->id && password_verify($valid->password, $user->password)) {

            // Generete token
            $userData = ['id' => $user->id];
            $token = Token::generate($userData, $valid->remember ? null : "+40 seconds");

            return RES::return(RES::SUCCESS, null, ['token' => $token]);
        } else {

            // Filter as invalid
            Filter::check([
                ['username', null, TRUE],
                ['password', null, TRUE]
            ])->throw(lang(self::LOGIN_ERROR));
        }
    }

    /**
     * Register method
     * 
     * @param object $req
     * 
     * @return RES
     */
    static function register(object $req)
    {

        // Validation
        $valid = (object) Filter::check([
            ['firstName', $req->firstName, TRUE],
            ['username', $req->username, TRUE, Filter::IS_USERNAME],
            ['username', $req->username, TRUE, function ($username) {
                return (bool) !self::where("username = :username")->read(['username' => $username])->data->id;
            }, 'username arrady exist'],
            ['email', $req->email, TRUE, Filter::IS_EMAIL],
            ['password', $req->password, TRUE],
            ['confirmPassword', $req->confirmPassword, TRUE, $req->confirmPassword === $req->password],
        ])->throw()->valid;

        // Create account
        return self::insert([
            'type' => 'user',
            'username' => $valid->username,
            'password' => password_hash($valid->password, PASSWORD_DEFAULT)
        ]);
    }
}
