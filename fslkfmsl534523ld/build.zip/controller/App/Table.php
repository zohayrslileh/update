<?php

namespace APP;

use TOOL\HTTP\Filter;
use TOOL\SQL\Curd\Extension as CurdExtension;

class Table extends CurdExtension
{

    /**
     * Curd options
     * 
     * @var array
     */
    protected static array $curdOptions = [
        'table' => 'tables',
        'tableKey' => 'id',
        'ACCESS_READ' => true,
        'ACCESS_CREATE' => true,
        'ACCESS_UPDATE' => true,
        'ACCESS_DELETE' => true
    ];

    /**
     * Create method
     * 
     * @param object $req
     * 
     * @return
     */
    static function create(object $req)
    {

        // Validation
        $valid = Filter::check([
            [
                'area_id',
                $req->areaId,
                TRUE,
                function ($id) {
                    return Area::read($id)->data->id;
                },
                lang('Not found area')
            ],
            ['name', $req->name, TRUE]
        ])->throw()->valid;

        return self::insert($valid);
    }

    /**
     * Custom update method
     * 
     * @param int $id
     * 
     * @param object $req
     * 
     * @return
     */
    static function customUpdate(int $id, object $req)
    {

        // Filter
        $valid = Filter::check([
            ['name', $req->name, TRUE]
        ])->throw()->valid;

        return self::where($id)->update($valid);
    }

    /**
     * Record method
     * 
     * @param object $req
     * 
     * @return
     */
    static function record(object $req)
    {

        $Record = self::prepareRecord();

        $Record->setFilter(
            "AND area_id = :area",
            ['area' => $req->area],
            $req->area
        );

        $Record->setFilter(
            "AND name LIKE CONCAT('%', :keyword, '%')",
            ['keyword' => $req->keyword],
            $req->keyword
        );

        $Record->prepare(false);

        return $Record->page($req->page)->get();
    }
}
