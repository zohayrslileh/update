<?php

namespace APP;

use Dompdf\Dompdf;
use Throwable;
use TOOL\HTTP\RES;
use TOOL\Network\Mailer;
use \TOOL\SQL\Curd\Extension as CurdExtension;
use TOOL\SQL\SQL;

class Daily extends CurdExtension
{

    /**
     * LAST_DAY_CONDITION
     * 
     * @var string
     */
    private const LAST_DAY_CONDITION = "close_at IS NULL ORDER BY id DESC LIMIT 1";


    /**
     * Curd options
     * 
     * @var array
     */
    protected static array $curdOptions = [
        'table' => 'daily',
        'tableKey' => 'id',
        'ACCESS_READ' => true,
        'ACCESS_CREATE' => true,
        'ACCESS_UPDATE' => true
    ];


    /**
     * Generate method
     * 
     * @return
     */
    static function generate()
    {
        return self::insert(['id' => 'id']);
    }

    /**
     * Use day method
     * 
     * @return
     */
    static function useDay()
    {
        // Define day
        $day = self::where(self::LAST_DAY_CONDITION)->read();

        if ($day->data->id)
            return $day;

        // Generate as new
        self::generate();

        return self::where(self::LAST_DAY_CONDITION)->read();
    }

    /**
     * Send email method
     * 
     * @param $data
     */
    private static function sendEmail($data)
    {
        // Generate pdf file
        $dompdf = new Dompdf();
        $dompdf->loadHtml(template('/email/report.php', ['data' => $data]));
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        // Generate new report
        file_put_contents($file = BASESTORAGE . '/cache/' .  mt_rand() . '.pdf', $dompdf->output());

        // Send report to mail
        Mailer::file($file);

        // Detele old report
        unlink($file);
    }

    /**
     * Send Report
     * 
     * @param ?int $id
     * 
     * @return
     */
    static function report(?int $id)
    {
        // Get data
        $data = SQL::set("SELECT * FROM orders WHERE daily_id = :dailyId")->ferchAll([
            'dailyId' => $id ?? self::useDay()->data->id
        ]);

        try {

            template('/thermal/report.php', ['data' => $data]);
        } catch (Throwable $error) {

            unset($error);
        }

        try {

            self::sendEmail($data);
        } catch (Throwable $error) {

            unset($error);
        }

        return RES::return(RES::SUCCESS);
    }

    /**
     * Renewal method
     * 
     * @return
     */
    static function renewal()
    {
        // Define use day
        $useDay = self::useDay()->data->id;

        // Close this day
        self::where(self::LAST_DAY_CONDITION)->update(['close_at' => date('Y-m-d H:i:s')]);

        // Generate new day
        $generate = self::generate();

        self::report($useDay);

        return $generate;
    }

    /**
     * Record method
     * 
     * @param object $req
     * 
     * @return
     */
    static function record(object $req)
    {
        $Record = self::prepareRecord([
            'record' => "SELECT *
            FROM daily
            LEFT JOIN (
                SELECT daily_id,
                SUM(income) AS income,
                SUM(profit) AS profit,
                COUNT(id) AS countOrder
                FROM orders
                LEFT JOIN (
                    SELECT order_id,
                    SUM(price * qnt) AS income,
                    SUM((price - capital) * qnt) AS profit
                    FROM sales
                    GROUP BY order_id
                ) AS sales ON sales.order_id = orders.id
                GROUP BY daily_id
            ) AS orders ON orders.daily_id = daily.id",
            'results' => "SUM(income) AS incomes,
            SUM(profit) AS profits,
            SUM(countOrder) AS countOrders"
        ]);

        $Record->setOrder('id', $req->orders->id);
        $Record->setOrder('income', $req->orders->income);
        $Record->setOrder('profit', $req->orders->profit);

        $Record->setFilter("AND DATE(create_at) >= :from", ['from' => $req->from], $req->from);
        $Record->setFilter("AND DATE(create_at) <= :to", ['to' => $req->to], $req->to);

        return $Record->get();
    }

    /**
     * Orders method
     * 
     * @param int $id
     * 
     * @param object $req
     * 
     * @return
     */
    static function orders(int $id, object $req)
    {
        $Record = self::prepareRecord([
            'record' => "SELECT *
            FROM orders
            LEFT JOIN (
                SELECT order_id,
                SUM(price * qnt) AS total,
                SUM((price - capital) * qnt) AS profit,
                COUNT(id) AS items 
                FROM sales
                GROUP BY order_id
            ) AS sales ON sales.order_id = orders.id
            WHERE daily_id = :id",
            'results' => "SUM(total) AS totals,
            SUM(profit) AS profits"
        ]);

        $Record->setOrder('id', $req->orders->id);
        $Record->setOrder('items', $req->orders->items);
        $Record->setOrder('total', $req->orders->total);
        $Record->setOrder('profit', $req->orders->profit);

        return $Record->get(['id' => $id]);
    }
}
