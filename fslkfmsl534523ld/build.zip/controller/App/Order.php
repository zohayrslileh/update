<?php

namespace APP;

use TOOL\HTTP\RES;
use TOOL\HTTP\RESException;
use TOOL\SQL\Curd\Extension as CurdExtension;

class Order extends CurdExtension
{

    /**
     * Curd options
     * 
     * @var array
     */
    protected static array $curdOptions = [
        'table' => 'orders',
        'tableKey' => 'id',
        'ACCESS_READ' => true,
        'ACCESS_CREATE' => true,
        'ACCESS_UPDATE' => true,
        'ACCESS_DELETE' => true
    ];


    /**
     * By table method
     * 
     * @param int $id
     * 
     * @param int $noPeople
     * 
     * @return
     */
    static function byTable(int $id, int $noPeople)
    {

        // Define table
        $table = Table::read($id)->data;

        if (!$table->id)
            throw new RESException(RES::ERROR, lang('Not found table'));

        // Define area
        $area = Area::read($table->area_id)->data;

        return Order::insert([
            'daily_id' => Daily::useDay()->data->id,
            'type' => 'table',
            'table_id' => $table->id,
            'table_area' => $area->name,
            'table_name' => $table->name,
            'no_people' => $noPeople
        ]);
    }

    /**
     * By import method
     * 
     * @return
     */
    static function byImport()
    {
        return Order::insert([
            'daily_id' => Daily::useDay()->data->id,
            'type' => 'import'
        ]);
    }

    /**
     * By delivery method
     * 
     * @param int $id
     * 
     * @return
     */
    static function byDelivery(int $id)
    {

        // Define customer
        $customer = Customer::read($id)->data;

        if (!$customer->id)
            throw new RESException(RES::ERROR, 'Not found customer');

        return Order::insert([
            'daily_id' => Daily::useDay()->data->id,
            'type' => 'delivery',
            'customer_id' => $customer->id,
            'customer_name' => $customer->name,
            'customer_address' => $customer->address,
            'customer_phone' => $customer->phone
        ]);
    }

    /**
     * Full payment method
     * 
     * @param int $id
     * 
     * @return
     */
    static function fullPayment(int $id)
    {

        self::where($id)->update(['paid' => true]);
    }

    /**
     * Get method
     * 
     * @param int $id
     * 
     * @return
     */
    static function get(int $id)
    {

        $order = (array) self::read($id)->data;
        $items = Sale::where('order_id = :id')->readAll(['id' => $id])->data;

        return RES::return(
            RES::SUCCESS,
            null,
            (object) ($order + ['items' => $items])
        );
    }
}
