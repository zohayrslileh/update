<?php

namespace APP;

use TOOL\HTTP\Filter;
use TOOL\HTTP\RES;
use TOOL\System\JSON;

class Settings
{

    /**
     * SETTINGS
     * 
     * @var string
     */
    private const SETTINGS = BASESTORAGE . '/settings.json';


    /**
     * Open method
     * 
     * @return JSON
     */
    private static function open()
    {

        return JSON::open(self::SETTINGS);
    }

    /**
     * Get method
     * 
     * @return object
     */
    static function get()
    {

        return self::open()->read();
    }

    /**
     * Get printers method
     * 
     * @return
     */
    static function getPrinters()
    {

        return RES::return(RES::SUCCESS, null, self::open()->go('/printers')->read());
    }

    /**
     * Set printers method
     * 
     * @param object $req
     * 
     * @return
     */
    static function setPrinters(object $req)
    {

        $valid = Filter::check([
            ['kitchen', $req->kitchen],
            ['bartender', $req->bartender],
            ['cashier', $req->cashier]
        ])->throw()->valid;

        self::open()->go('/printers')->set($valid)->save();

        return RES::return(RES::SUCCESS);
    }

    /**
     * Get company method
     * 
     * @return
     */
    static function getCompany()
    {

        return RES::return(RES::SUCCESS, null, self::open()->go('/company')->read());
    }

    /**
     * Set company method
     * 
     * @param object $req
     * 
     * @return
     */
    static function setCompany(object $req)
    {

        $valid = Filter::check([
            ['name', $req->name],
            ['phone', $req->phone],
            ['address', $req->address],
            ['logo', $req->logo, FALSE, pathinfo($req->logo, PATHINFO_EXTENSION) === 'jpg', 'Enable just jpg']
        ])->throw()->valid;

        self::open()->go('/company')->set($valid)->save();

        return RES::return(RES::SUCCESS);
    }

    /**
     * Get ticket method
     * 
     * @return
     */
    static function getTicket()
    {

        return RES::return(RES::SUCCESS, null, self::open()->go('/ticket')->read());
    }

    /**
     * Set ticket method
     * 
     * @param object $req
     * 
     * @return
     */
    static function setTicket(object $req)
    {

        $valid = Filter::check([
            ['footer', $req->footer]
        ])->throw()->valid;

        self::open()->go('/ticket')->set($valid)->save();

        return RES::return(RES::SUCCESS);
    }

    /**
     * Get report method
     * 
     * @return
     */
    static function getReport()
    {

        return RES::return(RES::SUCCESS, null, self::open()->go('/report')->read());
    }

    /**
     * Set report method
     * 
     * @param object $req
     * 
     * @return
     */
    static function setReport(object $req)
    {

        $valid = Filter::check([
            ['emails', $req->emails, FALSE, function (string $emails) {
                return !array_filter(explode("\n", $emails), function ($email) {
                    return !filter_var($email, FILTER_VALIDATE_EMAIL);
                });
            }]
        ])->throw()->valid;

        self::open()->go('/report')->set($valid)->save();

        return RES::return(RES::SUCCESS);
    }
}
