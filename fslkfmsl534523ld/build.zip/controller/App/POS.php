<?php

namespace APP;

use Throwable;
use TOOL\HTTP\Filter;
use TOOL\HTTP\RES;
use TOOL\HTTP\RESException;

class POS
{

    /**
     * Order method
     * 
     * @param object $req
     * 
     * @return
     * 
     */
    static function order(object $req)
    {

        // Step 1: Validation
        $valid = self::validation($req->items);


        // Step 2: Generate order
        if ($req->type === 'table')
            $order = Order::byTable($req->table, $req->noPeople);

        else if ($req->type === 'import')
            $order = Order::byImport();

        else if ($req->type === 'delivery')
            $order = Order::byDelivery($req->customer);

        else
            throw new RESException(RES::ERROR, 'Not found type');

        // Step 3: Sale
        Sale::order(array_map(function ($item) use ($order) {
            return $item + ['order_id' => $order->data->id];
        }, $valid));


        // Step 4: Payment
        if ($req->payment)
            Order::fullPayment($order->data->id);


        // Step 5: Print
        try {

            if ($req->kitchen)
                self::kitchenPrint($order->data->id);
        } catch (Throwable $error) {

            unset($error);
        }

        try {

            if ($req->bartender)
                self::bartenderPrint($order->data->id);
        } catch (Throwable $error) {

            unset($error);
        }

        try {

            if ($req->cashier)
                self::cashierPrint($order->data->id);
        } catch (Throwable $error) {

            unset($error);
        }

        try {

            if ($req->payment)
                self::paymentPrint($order->data->id);
        } catch (Throwable $error) {

            unset($error);
        }


        return $order;
    }

    /**
     * Validation method
     * 
     * @param array $items
     * 
     * @return array
     */
    private static function validation(array $items)
    {

        // Step 1: Check items is found
        if (!$items)
            throw new RESException(RES::ERROR, lang('Not found items'));


        // Step 2: Validation
        $valid = Filter::multiCheck(function ($item) {

            // Define menu
            $menu = Menu::read($item->id)->data;

            // Define category
            $category = Category::read($menu->category_id)->data;

            // Define title
            $title = "{$category->name} {$menu->name}";

            return [
                ['menu_id', $menu->id, TRUE, FILTER_VALIDATE_INT, lang('Item not valid')],
                ['menu_id', $menu->id, TRUE, is_null($menu->quantity) || $menu->quantity >= $item->qnt, "{$menu->quantity} \"{$title}\" " . lang('left')],
                ['qnt', $item->qnt, TRUE, FILTER_VALIDATE_FLOAT, lang('Qnt not valid')],
                ['note', $item->note],
                ['equips_in', $menu->equips_in],
                ['title', $title],
                ['price', $menu->price],
                ['capital', $menu->capital],
                ['left', is_null($menu->quantity) ? null : $menu->quantity - $item->qnt]
            ];
        }, $items)->throw()->valid;

        return $valid;
    }

    /**
     * Kitchen print method
     * 
     * @param int $order
     * 
     * @return
     */
    static function kitchenPrint(int $order)
    {

        template('/thermal/kitchen.php', [
            'order' => Order::get($order)->data
        ]);

        return RES::return(RES::SUCCESS);
    }

    /**
     * Bartender print method
     * 
     * @param int $order
     * 
     * @return
     */
    static function bartenderPrint(int $order)
    {

        template('/thermal/bartender.php', [
            'order' => Order::get($order)->data
        ]);

        return RES::return(RES::SUCCESS);
    }

    /**
     * Cashier print method
     * 
     * @param int $order
     * 
     * @return
     */
    static function cashierPrint(int $order)
    {

        template('/thermal/cashier.php', [
            'order' => Order::get($order)->data
        ]);

        return RES::return(RES::SUCCESS);
    }

    /**
     * Cashier payment method
     * 
     * @param int $order
     * 
     * @return
     */
    static function paymentPrint(int $order)
    {

        template('/thermal/payment.php', [
            'order' => Order::get($order)->data
        ]);

        return RES::return(RES::SUCCESS);
    }
}
