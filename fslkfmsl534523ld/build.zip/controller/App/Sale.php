<?php

namespace APP;

use TOOL\SQL\Curd\Extension as CurdExtension;

class Sale extends CurdExtension
{

    /**
     * Curd options
     * 
     * @var array
     */
    protected static array $curdOptions = [
        'table' => 'sales',
        'tableKey' => 'id',
        'ACCESS_READ' => true,
        'ACCESS_CREATE' => true,
        'ACCESS_UPDATE' => true,
        'ACCESS_DELETE' => true
    ];

    /**
     * Order method
     * 
     * @param array $items
     * 
     * @return
     */
    static function order(array $items)
    {
        // Update stock
        foreach ($items as $item) {

            if (!is_null($item['left']))
                Menu::where($item['menu_id'])->update(['quantity' => $item['left']]);
        }

        // Sale
        return self::prepareInsert(
            ['order_id', 'menu_id', 'equips_in', 'title', 'price', 'capital', 'qnt', 'note']
        )->save($items);
    }
}
