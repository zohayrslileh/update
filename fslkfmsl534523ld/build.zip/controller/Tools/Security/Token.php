<?php

namespace TOOL\Security;

use TOOL\HTTP\RES;

class Token
{


    /**
     * Generate method
     * 
     * @param array $data
     * 
     * @param ?string $lifetime
     * 
     * @return string
     */
    static function generate(array $data, ?string $lifetime = null)
    {

        $path = session_save_path();

        // session path not exsits
        if (!$path) return false;

        // Try find avaliable token
        do {

            $token = hash('sha256', random_bytes(16));
        } while (file_exists($path . "/" . $token));


        // create data
        $import = [
            "lifetime" => strtotime($lifetime) ? strtotime($lifetime) : null,
            "data" => $data
        ];

        // save token
        file_put_contents($path . "/" . $token, json_encode($import));

        return $token;
    }

    /**
     * Verify method
     * 
     * @param string $token
     * 
     * @return object|false
     */
    static function verify(string $token)
    {
        $path = session_save_path();

        /* ==== If token not found ==== */
        if (!$token || !file_exists($path . "/" . basename($token)))
            return false;

        try {

            # Try export data
            $export = file_get_contents($path . "/" . basename($token));
            $export = json_decode($export);
            if (!$export->data)
                return false;

            # Check Token life time
            if ($export->lifetime && strtotime("now") > $export->lifetime) {
                self::destroy($token);
                return false;
            }

            return $export->data;
        } catch (\Exception $error) {

            return false;
        }
    }

    /**
     * @param string $token
     * 
     * @return
     */
    static function destroy(string $token)
    {
        $path = session_save_path();

        if (file_exists($path . "/" . basename($token)))
            unlink($path . "/" . basename($token));

        return RES::return(RES::SUCCESS);
    }
}
