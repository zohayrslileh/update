<?php

namespace TOOL\Security;

use TOOL\HTTP\REQ;
use TOOL\HTTP\RES;
use APP\User;

class Auth
{

    /**
     * Logged in
     * 
     * @param ?object
     */
    private static ?object $loggedIn = NULL;


    /**
     * Logged in method
     * 
     * @return ?object
     */
    static function loggedIn()
    {

        // Check has setup
        if (self::$loggedIn) return self::$loggedIn;

        # Check Token session
        if (!REQ::$auth || !$verify = Token::verify(REQ::$auth))
            return false;

        # Get user
        $user = User::read((int) $verify->id)->data;

        # Unvalid auth
        if (!$user->id) return null;

        // Unset password
        unset($user->password);

        # Set loggedIn data
        return self::$loggedIn = $user;
    }

    /**
     * Header method
     * 
     * @param array $rules
     */
    static function header(?array $rules = null)
    {

        // Check auth
        if (!self::loggedIn())

            RES::api(RES::UNAUTH, 'UNAUTH');

        // Check rules
        if ($rules && !in_array(self::loggedIn()->type, $rules))

            RES::api(RES::UNRULE, 'UNRULE');
    }
}
