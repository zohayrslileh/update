<?php

namespace TOOL\System;

use TOOL\HTTP\RES;
use TOOL\SQL\SQL;

class Setup
{

    /**
     * Update method
     * 
     * @return
     */
    static function update()
    {

        require_once BASEDIR . '/controller/update.php';

        return RES::return(RES::SUCCESS);
    }

    /**
     * Format method
     * 
     * @return
     */
    static function format()
    {

        $database = App::config()->DATABASE_NAME;
        SQL::run("DROP database `{$database}`; CREATE database `{$database}`;");

        Path::open(BASESTORAGE)->delete();
        Path::open(BASEUPLOAD)->delete();

        return RES::return(RES::SUCCESS);
    }
}
