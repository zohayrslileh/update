<?php

namespace TOOL\System;

class App
{

    /**
     * PATH_CONFIG
     * 
     * @var string
     */
    private const PATH_CONFIG = BASEDIR . '/.config';

    /**
     * Config
     * 
     * @var ?object
     */
    private static ?object $config = NULL;

    
    /**
     * Config method
     * 
     * @return object
     */
    static function config()
    {

        // Check has setup
        if (self::$config) return self::$config;

        return self::$config = JSON::open(self::PATH_CONFIG)->read();
    }

    /**
     * Set method
     * 
     * @param array $parameters
     */
    static function set(array $parameters)
    {

        JSON::open(self::PATH_CONFIG)->set($parameters)->save();

        // Ready config to render
        self::$config = NULL;
    }
}
