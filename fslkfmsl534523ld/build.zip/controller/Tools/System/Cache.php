<?php

namespace TOOL\System;

class Cache
{

    /**
     * CACHE_DIR
     * 
     * @var string
     */
    private const CACHE_DIR = BASESTORAGE . '/cache/';


    /**
     * Generate method
     * 
     * @param array $data
     * 
     * @return string
     */
    static function generate(array $data = [])
    {

        // Try find avaliable token
        do {

            $token = hash('sha256', random_bytes(16));
        } while (file_exists(self::CACHE_DIR . "/" . $token));


        // Save cache
        file_put_contents(self::CACHE_DIR . "/" . $token, json_encode($data));

        return $token;
    }



    /**
     * Update method
     * 
     * @param string $token
     * 
     * @param array $data
     * 
     * @return string
     */
    static function update(string $token, array $data)
    {

        // Save cache
        file_put_contents(self::CACHE_DIR . "/" . basename($token), json_encode($data));

        return $token;
    }


    /**
     * Get method
     * 
     * @param ?string $token
     * 
     * @return object
     */
    static function get(?string $token)
    {
        // Check cache is found
        if (!$token || !file_exists(self::CACHE_DIR . "/" . basename($token)))
            return null;

        try {

            # Try export data
            $export = file_get_contents(self::CACHE_DIR . "/" . basename($token));
            $export = json_decode($export);

            return (object) $export;
        } catch (\Exception $error) {

            return null;
        }
    }


    /**
     * Destroy method
     * 
     * @param string $token
     * 
     * @return bool
     */
    static function destroy(string $token)
    {

        if (file_exists(self::CACHE_DIR . "/" . basename($token)))
            unlink(self::CACHE_DIR . "/" . basename($token));

        return true;
    }
}
