<?php

namespace TOOL\SQL;

use TOOL\System\App;

class Database
{

    /**
     * Server
     * 
     * @var ?\PDO
     */
    private static ?\PDO $server = NULL;

    /**
     * Conn
     * 
     * @var ?\PDO
     */
    private static ?\PDO $conn = NULL;


    /**
     * Server method
     * 
     * @return \PDO
     */
    static function server()
    {

        // Check has setup
        if (self::$server) return self::$server;

        # Database data
        $App = App::config();

        # Create connection
        self::$server = new \PDO(
            "mysql:host=$App->DATABASE_HOST",
            $App->DATABASE_USER,
            $App->DATABASE_PASS
        );

        # Set the PDO attributes
        self::$server->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        self::$server->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        return self::$server;
    }

    /**
     * Conn method
     * 
     * @return \PDO
     */
    static function conn()
    {

        // Check has setup
        if (self::$conn) return self::$conn;

        # Database data
        $App = App::config();

        # Create connection
        self::$conn = new \PDO(
            "mysql:host=$App->DATABASE_HOST;dbname=$App->DATABASE_NAME",
            $App->DATABASE_USER,
            $App->DATABASE_PASS
        );

        # Set the PDO attributes
        self::$conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        self::$conn->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        return self::$conn;
    }

    /**
     * Database __destruct
     * 
     */
    function __destruct()
    {

        self::$server = null;
        self::$conn = null;
    }
}
