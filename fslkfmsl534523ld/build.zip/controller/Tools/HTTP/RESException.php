<?php

/*
|-----------------------------
|        RESException
|-----------------------------
|
|
*/


namespace TOOL\HTTP;


class RESException extends \Exception
{

    /**
     * Res
     * 
     * @var RES
     */
    public RES $res;


    /**
     * RESException __construct
     * 
     * @param int $type
     * 
     * @param string $message
     * 
     * @param $data
     */
    function __construct(int $type, string $message = null, $data = null)
    {

        $this->res = new RES($type, $message, $data);

        parent::__construct($message);
    }
}
