<?php

namespace TOOL\HTTP;

class REQ
{

    /**
     * URI
     * 
     * @var array
     */
    public static array $uri;

    /**
     * Query
     * 
     * @var object
     */
    public static object $query;

    /**
     * Method
     * 
     * @var string
     */
    public static string $method;

    /**
     * Input
     * 
     * @var ?object
     */
    public static ?object $input;

    /**
     * Auth
     * 
     * @var string
     */
    public static ?string $auth;

    /**
     * Custom
     * 
     * @var ?object
     */
    public static ?object $custom;


    /**
     * URI method
     * 
     * @param ?string $uri
     * 
     * @return array
     */
    public static function uri(?string $uri)
    {

        // Filter URI
        $uri = preg_replace('/(\/+)/', '/', $uri);
        $uri = filter_var($uri, FILTER_SANITIZE_URL);
        $uri = rtrim($uri, '/');
        $uri = strtok($uri, '?');
        $uri = explode('/', $uri);

        return $uri;
    }

    /**
     * Setup method
     * 
     */
    public static function setup()
    {

        // Read URI
        self::$uri = self::uri($_SERVER['REQUEST_URI']);

        // Read query
        self::$query = (object) $_REQUEST;

        // Read method
        self::$method = $_SERVER['REQUEST_METHOD'];

        // Read input
        self::$input = (object) json_decode(file_get_contents("php://input"));

        // Read auth
        self::$auth = getallheaders()['Authorization'];

        // Read custom header
        self::$custom = json_decode(getallheaders()['Custom']);
    }
}
