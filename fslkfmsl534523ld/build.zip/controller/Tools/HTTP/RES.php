<?php

/*
|-----------------------------
|            RES
|-----------------------------
|
|
*/


namespace TOOL\HTTP;

class RES
{

    /**
     * TYPES
     * 
     */
    const ERROR = 0;
    const SUCCESS = 1;
    const WARNING = 2;
    const INVALID = 3;
    const UNAUTH = 4;
    const UNAPI = 5;
    const UNRULE = 6;
    const SERVER_ERROR = 7;
    const USERETURN = 10;

    /**
     * Exceptions
     * 
     */
    private const EXCEPTIONS = [
        self::ERROR,
        self::SERVER_ERROR
    ];


    /**
     * Type
     * 
     * @var int
     */
    public int $type;

    /**
     * Message
     * 
     * @var ?string
     */
    public ?string $message;

    /**
     * Data
     * 
     * @var
     */
    public $data;

    /**
     * Return
     * 
     * @var ?object
     */
    private static ?object $return = null;


    /**
     * RES __construct
     * 
     * @param int $type
     * 
     * @param string $message
     * 
     * @param $data
     */
    function __construct(int $type, string $message = null, $data = null)
    {

        $this->type = $type;
        $this->message = $message;
        $this->data = $data;
    }


    /**
     * Add data method
     * 
     * @param $data
     */
    function addData($data)
    {

        $this->data = (object) array_merge(
            (object) $this->data,
            (object) $data
        );
    }


    /**
     * Print json method
     * 
     */
    function print()
    {

        self::api($this->type, $this->message, $this->data);
    }


    /**
     * Throw method
     * 
     * @param array $exceptions
     */
    function throw(array $exceptions = self::EXCEPTIONS)
    {

        if (in_array(
            $this->type,
            $exceptions
        ))
            throw new RESException($this->type, $this->message, $this->data);
    }


    /**
     * Return method
     * 
     * @param int $type
     * 
     * @param string $message
     * 
     * @param $data
     * 
     * @return self
     */
    static function return(int $type, string $message = null, $data = null)
    {

        // Check if type is USERETURN
        if ($type === self::USERETURN && self::$return) {

            $type = self::$return->type;
            $message = self::$return->message;
            $data = self::$return->data;
        }

        // Not found old return
        else if ($type === self::USERETURN) {

            $type = self::SERVER_ERROR;
            $message = 'unfound return';
        }


        // Save return
        self::$return = (object) [
            'type' => $type,
            'message' => $message,
            'data' => $data
        ];

        return new self($type, $message, $data);
    }


    /**
     * Api method
     * 
     * @param int $type
     * 
     * @param string $message
     * 
     * @param $data
     */
    static function api(int $type, ?string $message = null, $data = null)
    {

        // Create return
        $return = self::return($type, $message, $data);

        // Generate response
        $response = [
            'type' => $return->type,
            'message' => $return->message,
            'data' => $return->data
        ];

        /**
         * Clear memory
         * finish the script
         * and print the result to the user as json
         */
        ob_end_clean();
        exit(json_encode(
            $response
        ));
    }

    /**
     * Html method
     * 
     * @param string $filename
     */
    static function html(string $filename)
    {

        // Set html header
        header("Content-type: text/html");

        /**
         * Clear memory
         * finish the script
         * and print the result to the user as html page
         */
        ob_end_clean();
        exit(file_get_contents(
            $filename
        ));
    }
}
