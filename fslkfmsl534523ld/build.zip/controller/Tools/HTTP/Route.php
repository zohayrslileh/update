<?php

/*
|-----------------------------
|           Route
|-----------------------------
|
|
*/


namespace TOOL\HTTP;

class Route
{

    /**
     * BAD_REQUEST
     * 
     * @var string
     */
    private const BAD_REQUEST = BASEDIR . '/controller/Router/http/interface/errors/badRequest.html';

    /**
     * BREAK
     * 
     * @var int
     */
    public const BREAK = -1;

    /**
     * Close
     * 
     * @var bool
     */
    private static bool $close = false;

    /**
     * Break
     * 
     * @var bool
     */
    private static bool $break = false;

    /**
     * Parent URI
     * 
     * @var array
     */
    private static array $parentURI = [];

    /**
     * Params
     * 
     * @var array
     */
    public static array $params = [];

    
    /**
     * Run routes
     * 
     * @param $action
     * 
     * @param bool $recovery
     */
    public static function ready($action, bool $recovery = true)
    {

        // Open the route
        self::$close = false;

        // Check save to the old parend
        $parentURI = self::$parentURI;

        // Try action as callback
        if (is_callable($action))
            call_user_func($action, (object) self::$params);

        // Try include action as file
        else if (is_string($action))
            require $action;

        // Check back to the old parend
        if ($recovery) self::$parentURI = $parentURI;

        // Close the route
        self::$close = true;
    }

    /**
     * New path
     * 
     * @param string $methods
     * 
     * @param string $to
     * 
     * @param $action
     * 
     * @param bool $group
     */
    private static function path(string $methods = null, string $to, $action = null, bool $group = false)
    {

        // Check that the route is open
        // And There is no break process
        if (self::$close || self::$break) return;

        // Extracting the URI of the child
        $ChildURI = array_slice(
            REQ::$uri,
            sizeof(self::$parentURI),
            sizeof(REQ::$uri)
        );

        // Extract the desired URI
        $to = REQ::uri($to);

        // Removing the starting point in the event of an parent path
        if (self::$parentURI) array_shift($to);

        // Check sure the path is complete
        if (!$group && sizeof($ChildURI) > sizeof($to)) return;


        /**
         * Road comparison
         */
        foreach ($to as $index => $route) {

            # Check the URI is variable
            if ($route && $route[0] === ':') {
                self::$params[ltrim($route, ':')] = $ChildURI[$index];
                continue;
            }

            # URI comparison
            if ($route != $ChildURI[$index])
                return;
        }

        // Parent URI update
        self::$parentURI = array_merge(self::$parentURI, $to);

        // Check the methods request
        if ($methods && !in_array(REQ::$method, explode('|', $methods)))
            RES::html(self::BAD_REQUEST);

        // Try action as callback
        if (is_callable($action))
            call_user_func($action, (object) self::$params);

        // Try include action as file
        else if (is_string($action))
            require $action;

        // Close the route
        self::$close = true;
    }

    /**
     * Group routes
     * 
     * @param string $to
     * 
     * @param $action
     */
    public static function group(string $to, $action = null)
    {

        self::path(null, $to, $action, true);
    }

    /**
     * Default route
     * 
     * @param $action
     */
    public static function default($action = null)
    {

        self::path(null, '/', $action);
    }

    /**
     * To route
     * 
     * @param string $to
     * 
     * @param $action
     */
    public static function to(string $to, $action = null)
    {

        self::path(null, $to, $action);
    }

    /**
     * GETS routes
     * 
     * @param string $to
     * 
     * @param $action
     */
    public static function gets(string $to, $action = null)
    {

        self::path('GET', $to, $action, true);
    }

    /**
     * GET route
     * 
     * @param string $to
     * 
     * @param $action
     */
    public static function get(string $to, $action = null)
    {

        self::path('GET', $to, $action);
    }

    /**
     * POSTS routes
     * 
     * @param string $to
     * 
     * @param $action
     * 
     */
    public static function posts(string $to, $action = null)
    {

        self::path('POST', $to, $action, true);
    }

    /**
     * POST route
     * 
     * @param string $to
     * 
     * @param $action
     */
    public static function post(string $to, $action = null)
    {

        self::path('POST', $to, $action);
    }

    /**
     * ELSE route
     * 
     * @param $action
     * 
     * @param bool $mandatory
     */
    public static function else($action, bool $mandatory = false)
    {

        // Check that the route is open
        // Or There is break process
        // Or There is a mandatory pass
        if (self::$close && !self::$break && !$mandatory) return;

        // Stop the break
        self::$break = false;

        // Try action as callback
        if (is_callable($action))
            call_user_func($action, (object) self::$params);

        // Try include action as file
        else if (is_string($action))
            require $action;

        // Try action as constant actions
        else if ($action === self::BREAK)
            self::break();

        // Close the route
        self::$close = true;
    }

    /**
     * Extract params
     * 
     * @param string $prop object
     * 
     * @return string|object
     */
    static function params(string $prop = null)
    {

        // Extract saved variables
        if ($prop)
            return self::$params[$prop];
        else
            return (object) self::$params;
    }

    /**
     * Break to Else
     * 
     */
    static function break()
    {

        self::$break = true;
    }
}
