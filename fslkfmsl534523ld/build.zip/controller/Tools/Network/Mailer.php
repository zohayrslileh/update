<?php

namespace TOOL\Network;

use APP\Settings;
use PHPMailer\PHPMailer\PHPMailer;
use TOOL\HTTP\RES;
use TOOL\HTTP\RESException;
use TOOL\Security\Auth;
use TOOL\System\App;

class Mailer
{

    /**
     * File method
     * 
     * @param string $attch
     */
    static function file(string $attch)
    {

        $App = App::config();
        $settings = Settings::get();

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $App->SMTP_HOST;
        $mail->Port = $App->SMTP_PORT;
        $mail->SMTPSecure = 'tls';
        $mail->SMTPAuth = true;
        $mail->Username = $App->SMTP_USER;
        $mail->Password = 'azert1234567$';
        $mail->SetFrom($App->SMTP_USER, $App->APP_NAME);

        foreach (explode("\n", $settings->report->emails) as $email) {

            $mail->addAddress($email);
        }

        $mail->IsHTML(true);
        $mail->Subject = 'Rapport: ' . Auth::loggedIn()->username;
        $mail->Body    = 'Rapport';
        $mail->addAttachment($attch);
        $mail->AltBody = 'Rapport';

        $mail->send();
    }
}
