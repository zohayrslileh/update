<?php

namespace TOOL\Helper;

use TOOL\System\JSON;
use TOOL\System\App;

class Lang
{

    /**
     * BASE
     * 
     * @var string
     */
    private const BASE = BASERESOURCES . '/langue';

    /**
     * Words
     * 
     * @var ?array
     */
    private static ?array $words = null;


    /**
     * Tran method
     * 
     * @param string $word
     * 
     * @return
     */
    static function tran(string $word)
    {

        // Check has not setup
        if (!self::$words)
            self::$words = (array) JSON::open(self::BASE . '/' . App::config()->APP_LANG . '.json')->read();

        return self::$words[$word] ?? $word;
    }
}
