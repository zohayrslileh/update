<?php

use APP\Area;
use TOOL\Security\Auth;

/**
 * |------
 * | AUTH
 * |------
 */
Auth::header(['admin']);

Area::list()->print();
