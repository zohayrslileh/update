<?php

use TOOL\HTTP\Route;

/**
 * |------------------------
 * |         USER
 * |------------------------
 */

Route::to('/login', __DIR__ . '/login.php');
Route::to('/auth', __DIR__ . '/auth.php');
Route::to('/logout', __DIR__ . '/logout.php');
