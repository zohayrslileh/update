<?php

use TOOL\HTTP\REQ;
use TOOL\Security\Token;

Token::destroy(REQ::$auth)->print();
