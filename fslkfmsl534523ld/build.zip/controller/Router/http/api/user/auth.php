<?php

use TOOL\HTTP\RES;
use TOOL\Security\Auth;

/**
 * |------
 * | AUTH
 * |------
 */
Auth::header();

RES::api(
    RES::SUCCESS,
    null,
    [
        'details' => Auth::loggedIn()
    ]
);
