<?php

use TOOL\HTTP\Route;

/**
 * |------------------------
 * |         ORDER
 * |------------------------
 */

Route::to('/read/:id', __DIR__ . '/read.php');