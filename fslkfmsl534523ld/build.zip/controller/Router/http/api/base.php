<?php

use TOOL\HTTP\RES;
use TOOL\HTTP\RESException;
use TOOL\HTTP\Route;
use TOOL\System\App;

try {

    // App
    $App = App::config();
    header("Access-Control-Allow-Origin: {$App->API_ALLOW_ORIGIN}");
    header("Access-Control-Allow-Headers: {$App->API_ALLOW_HEADER}");
    header("Content-type: {$App->API_TYPE_CONTENT}; charset=utf-8");

    Route::group('/', __DIR__ . '/routes.php');
} catch (RESException $error) {

    RES::api($error->res->type, $error->res->message, $error->res->data);
} catch (Throwable $error) {

    if (App::config()->APP_DEBUG)
        RES::api(RES::SERVER_ERROR, $error->getMessage(), $error->getTrace());

    else
        RES::api(RES::SERVER_ERROR, 'Some thing not worning');
}
