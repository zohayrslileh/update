<?php

use TOOL\HTTP\Route;

/**
 * |------------------------
 * |         POS
 * |------------------------
 */

Route::to('/order/:id', __DIR__ . '/order.php');
Route::to('/kitchen-print/:id', __DIR__ . '/kitchen-print.php');