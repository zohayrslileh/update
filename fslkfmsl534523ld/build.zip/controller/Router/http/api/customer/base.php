<?php

use TOOL\HTTP\Route;

/**
 * |------------------------
 * |         Customer
 * |------------------------
 */

Route::to('/create', __DIR__ . '/create.php');
Route::to('/record', __DIR__ . '/record.php');