<?php

use APP\Daily;
use TOOL\Security\Auth;

/**
 * |------
 * | AUTH
 * |------
 */
Auth::header(['admin']);

Daily::renewal()->print();
