<?php

/**
 * |------------------------
 * |         HTTP
 * |------------------------
 */

use TOOL\HTTP\REQ;

/**
 * Autoload
 * 
 */
require_once BASEDIR . '/controller/vendor/autoload.php';

/**
 * Config
 * 
 */
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
date_default_timezone_set('Africa/Casablanca');
set_time_limit(300);

/**
 * Setup Request
 * 
 * REQ::$uri
 * REQ::$query
 * REQ::$method
 * REQ::$input
 * REQ::$auth
 * REQ::$custom
 */
REQ::setup();

/**
 * Routes
 * 
 */
require_once __DIR__ . '/routes.php';
