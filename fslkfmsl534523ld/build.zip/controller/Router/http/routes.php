<?php

/**
 * |------------------------
 * |       BASE ROUTES
 * |------------------------
 */

use TOOL\HTTP\Route;

// API
Route::group('/api', __DIR__ . '/api/base.php');

// APP
Route::group('/setup', __DIR__ . '/interface/index.php');

// APP
Route::group('/', BASEPUBLIC . '/index.html');
