<?php

/**
 * |------------------------
 * |        CONSOLE
 * |------------------------
 */

use TOOL\System\App;
use TOOL\System\Path;
use TOOL\System\Setup;

/**
 * Autoload
 * 
 */
require_once BASEDIR . '/controller/vendor/autoload.php';


if ($argv[1] === 'start') {

    Path::open(BASEDIR)
        ->go('public')
        ->command('explorer "http://localhost:8888"')
        ->command('php -S localhost:8888');
}

if ($argv[1] === 'build') {

    echo "Clear production interface \n";
    Path::open(BASEDIR)
        ->go('public')
        ->skip(['uploads', 'index.php'])
        ->clear();

    echo "Build production interface \n";
    Path::open(BASEDIR)
        ->go('interface')
        ->command("npm run production")
        ->go('/build')->move(BASEDIR . '/public');

    echo "Set APP_DEBUG = false\n";
    App::set(['APP_DEBUG' => false]);

    echo "Build app \n";
    Path::open(BASEDIR)
        ->skip(['interface', 'storage', 'public/uploads'])
        ->zip('build', BASEDIR);

    echo "Set APP_DEBUG = true\n";
    App::set(['APP_DEBUG' => true]);

    echo "Done \n";
}

if ($argv[1] === 'backup') {

    echo "Create backup \n";
    Path::open(BASEDIR)
        ->skip(['interface/node_modules'])
        ->zip('backup');

    echo "Done  \n";
}

if ($argv[1] === 'format') {

    echo "Format... \n";
    Setup::format();
    echo "Done \n";
}

if ($argv[1] === 'update') {

    echo "Update... \n";
    Setup::update();
    echo "Done \n";
}

if ($argv[1] === 'reinstall') {
    Path::open(BASEDIR)->command("php console format && php console update");
}
