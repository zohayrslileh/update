<?php


define('BASEPUBLIC', BASEDIR . '/public');
define('BASEINTERFACE', BASEDIR . '/interface');
define('BASERESOURCES', BASEDIR . '/controller/Resources');
define('BASESTORAGE', BASEDIR . '/storage');
define('BASEUPLOAD', BASEDIR . '/public/uploads');
