<?php

use TOOL\Helper\Lang;
use TOOL\Helper\Template;

/**
 * Lang method
 * 
 */
if (!function_exists('lang')) {
    function lang(string $word)
    {

        return Lang::tran($word);
    }
}

/**
 * Template method
 * 
 */
if (!function_exists('template')) {
    function template(string $path, array $params = [])
    {

        return Template::get(Template::BASE . $path, $params);
    }
}
